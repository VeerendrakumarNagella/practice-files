import React from 'react';
import './App.scss';
import Header from './components/common/header/header';
import Footer from './components/common/footer/footer';
import { IntlProvider } from 'react-intl';
import { connect } from 'react-redux';
import RouterConfig from './components/router';
import messages from './utilities/messages';
import {BrowserRouter as Router} from 'react-router-dom';

class App extends React.Component {
  render() {
    const {lang} = this.props;
    return (
      <IntlProvider locale={lang} messages={messages[lang]}>
        <Router>
          <Header />
          <section className="section-wrapper">
            <div className="container">
              <RouterConfig />
            </div>
          </section>
          <Footer />
        </Router>
      </IntlProvider>
    );
  }
  
}

const mapStateToProps = (state) => ({
  lang: state.locale.lang
});

export default connect(mapStateToProps)(App);
