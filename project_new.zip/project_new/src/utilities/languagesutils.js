import deImg from './../assets/images/lang/NL.png';
import enImg from './../assets/images/lang/EN-US.png';
import frImg from './../assets/images/lang/FR.png';
import geImg from './../assets/images/lang/DE.png';
import itImg from './../assets/images/lang/IT.png';
import ruImg from './../assets/images/lang/RU.png';
import plImg from './../assets/images/lang/pl-PL.png';
import trImg from './../assets/images/lang/tr-TR.png';
import chImg from './../assets/images/lang/china.png';
import esImg from './../assets/images/lang/ES.png';

export const LangOpt = [
    {
        name: "Dutch",
        lang: "nl",
        img: deImg
    },
    {
        name: "English",
        lang: "en",
        img: enImg
    },
    {
        name: "French",
        lang: "fr",
        img: frImg
    },
    {
        name: "German",
        lang: "de",
        img: geImg
    },
    {
        name: "Italian",
        lang: "it",
        img: itImg
    },
    {
        name: "Russian",
        lang: "ru",
        img: ruImg
    },
    {
        name: "Polish",
        lang: "pl",
        img: plImg
    },
    {
        name: "Turkish",
        lang: "tr",
        img: trImg
    },
    {
        name: "Simplified chinese",
        lang: "zn",
        img: chImg
    },
    {
        name: "Spanish",
        lang: "es",
        img: esImg
    },
    {
        name: "traditional chinese",
        lang: "zn",
        img: chImg
    },
];