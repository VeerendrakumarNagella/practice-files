import axios from 'axios';

export async function ServiceCall(MethodType, requrl, postBody) {
    const header = {
        "Content-Type": "application/json",
        'XUsername': 'patnamv'
    }

    let promise;
    
    //Actual API call
    if (MethodType === 'GET') {
        promise = axios.get(requrl, { headers: { ...header } });
    }
    else if (MethodType === 'POST') {
        promise = axios.post(requrl, postBody, { headers: { ...header } });
    }
    else if (MethodType === 'DELETE') {
        promise = axios.delete(requrl, { headers: { ...header } });
    }
    else if (MethodType === 'PUT') {
        promise = axios.put(requrl, postBody, { headers: { ...header } });
    }
    
    return promise.then((d) => {
        return d;
    }).catch((e) => {
        return e;
    });
}