import nlTranslate from './locale/translate-nl.json';
import enTranslate from './locale/translate-en.json';
import ruTranslate from './locale/translate-ru.json';
import frTranslate from './locale/translate-fr.json';
import deTranslate from './locale/translate-de.json';

export default {
    nl: nlTranslate,
    en: enTranslate,
    fr: frTranslate,
    de: deTranslate,
    ru: ruTranslate
}