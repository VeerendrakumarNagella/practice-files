import React from 'react';
import { Route, Switch } from 'react-router-dom';
import Dashboard from './dashboard/Dashboard';
import Projectinfo from './projectdetails/projectinfo';
import TagTemplate from './workflows/packagedchilleremea/tagtemplates/tagtemplates';

const RouterConfig = () => {
  return (
    <Switch>
      <Route exact path='/' component={Dashboard}/>
      <Route path='/ProjectDetail' component={Projectinfo}/>
      <Route path='/Template' component={TagTemplate}/>
    </Switch>
  )
}
export default RouterConfig;