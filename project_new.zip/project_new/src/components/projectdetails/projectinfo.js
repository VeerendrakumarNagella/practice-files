import React from 'react';
import './projectinfo.scss';
import {Link} from 'react-router-dom';
import Button from './../common/controls/button';
import CustomDropdown from './../common/controls/customDropdown';
import {PanelBar, PanelBarItem} from '@progress/kendo-react-layout';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlusSquare, faArrowAltCircleUp, faExternalLinkAlt, faChevronCircleLeft } from '@fortawesome/free-solid-svg-icons';

const Projectinfo = (props) => {
    return (
        <>
            <div className="backBtn">
                <Link to="/"><FontAwesomeIcon className="columncolor" icon={faChevronCircleLeft}  /></Link> Project 4956
            </div>
            <PanelBar>
                <PanelBarItem title="Project Information" className="panel-head">
                    <div className="panel-body">
                        <div className="panel-bdy-row"><span className="panel-bdy-title">Project Name</span> <span>Project 4956</span></div>
                        <div className="panel-bdy-row"><span className="panel-bdy-title">Customer Name</span> <span>venkatesh</span></div>
                        <div className="panel-bdy-row"><span className="panel-bdy-title">Contact Name</span></div>
                        <div className="panel-bdy-row"><span className="panel-bdy-title">Contact Email</span></div>
                    </div>
                </PanelBarItem>
            </PanelBar>
            <div className="command-bar">
                <h1>Selection Summary</h1>
                <div className="cmdbar-right">
                    <Button
                        name="Batch Upgarde"
                        styles="eButton"
                        icon={faArrowAltCircleUp}
                    />
                    <CustomDropdown
                        name="CSO Export"
                        icon={faExternalLinkAlt}
                    />
                    <CustomDropdown
                        name="Add Selection"
                        icon={faPlusSquare}
                    />
                </div>
            </div>
        </>
    )
}

export default Projectinfo;