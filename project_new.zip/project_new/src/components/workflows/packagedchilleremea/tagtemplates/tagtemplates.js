import React from 'react';
import './tagtemplates.scss';
import {PanelBar, PanelBarItem} from '@progress/kendo-react-layout';

const TagTemplate = (props) => {
    return (
        <>
            <PanelBar>
                <PanelBarItem expanded={true} title="What selection template do you want to use ?" className="panel-head">
                    <div className="panel-body">
                        Blank Template
                    </div>
                </PanelBarItem>
            </PanelBar>
        </>
    )
}

export default TagTemplate;