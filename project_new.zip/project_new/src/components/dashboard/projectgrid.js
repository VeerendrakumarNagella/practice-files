import React from 'react';
import { Grid, GridColumn as Column } from '@progress/kendo-react-grid';
import { connect } from 'react-redux';
import { getProjectList } from '../../redux/Actions/getProjectList';
import { orderBy } from '@progress/kendo-data-query';
import KendoGridActionsCell from './ActionsColumn.js';
import { withRouter } from 'react-router';
import axios from 'axios';

class Projectgrid extends React.Component {
    constructor() {
        super();
        this.state = {
            listitems: [],            
            total: 0,
            skip: 0,
            pageSizes: 10,
            take: 10,
            pageable: this.state ? this.state.pageable : {
                buttonCount: 5,
                info: true,
                type: 'numeric',
                pageSizes: true,
                previousNext: true,
            },
            sort: [
                { field: 'ProjectName', dir: 'asc' }
            ]
        }

        this.pageChange = this.pageChange.bind(this);
        this.onClickProjectDetail = this.onClickProjectDetail.bind(this);
        this.onClickProjectDownload = this.onClickProjectDownload.bind(this);
    }
    
    static getDerivedStateFromProps(props, state){
        let listitems = props.projectList.records;
      //  console.log(listitems);
        listitems = listitems.map((item) => {
            var initDate = new Date(item.LastModifiedDate);
            var formatdate = new Intl.DateTimeFormat('en-US', {year: 'numeric', month: '2-digit',day: '2-digit'}).format(initDate)
            item = {...item, "LastModifiedDate": formatdate};
            return item;
        });

        return { ...state, listitems };
    }

    componentDidMount() {
        if(!this.props.projectList.records.length) {
            this.props.getProjectList('sudheerkumar.tangudu@utc.com');
        }
    }

    pageChange = (event) => {
        this.setState({
            skip: event.page.skip,
            take: event.page.take
        });
    }
        
    render() {
        return (
            <>
                <Grid
                    className="k-grid-table"
                    data={orderBy(this.state.listitems.slice(this.state.skip, this.state.skip + this.state.take), this.state.sort)}
                    skip={this.state.skip}
                    take={this.state.take}
                    total={this.state.listitems.length}                                      
                    onPageChange={this.pageChange}                       
                    pageable={this.state.pageable}
                    pageSizes={this.state.pageSizes}                     
                    sortable
                    sort={this.state.sort}
                        onSortChange={(e) => {
                        this.setState({
                            sort: e.sort
                        });
                    }}
                >
                    <Column field="ProjectName" title="Project" width="300px" />
                    <Column field="ProjectCustomer" title="Customer" />
                    <Column field="ProjectOwner" title="Sales Person" />
                    <Column field="LastModifiedDate" title="Last Reviewed On" />                                  
                    <Column field="ProjectID" title="Actions" 
                        cell={(props) => 
                            <KendoGridActionsCell 
                                onClickProjectDetail={this.onClickProjectDetail} 
                                onClickProjectDownload={this.onClickProjectDownload}
                                onClickDeleteItem={this.onClickDeleteItem}
                                {...props} 

                                />
                        }
                        />
                </Grid>
            </>
        );
    }

    onClickProjectDetail(id) {
        this.props.history.push(`/ProjectDetail?ProjectId=${id}`);
    }

    onClickDeleteItem() {
        console.log("delete");
    }

    onClickProjectDownload(item) {
        let ProjectID = item.ProjectID;
        let projectName = item.ProjectName;

        let FillName; 
        if (projectName !== null && projectName !== "") { 
            FillName = projectName + "_" + Math.floor((new Date()).getTime() / 1000) + ".E4A";
        } else { 
            FillName = "Project" + "_" + Math.floor((new Date()).getTime() / 1000) + ".E4A";
        }

        var headers = {
            'Content-Type': 'application/json',
            'XUsername': 'sudheerkumar.tangudu@utc.com',
        }

        axios({
            url: `https://ngecatapplicationservice.azurewebsites.net/api/ProjectDetail/GetProjectDetail?projectId=${ProjectID}`,
            method: "GET",
            headers: headers
        }).then(res => {
            const url = window.URL.createObjectURL(new Blob([res.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', `${FillName}`);
            document.body.appendChild(link);
            link.click();
        }).catch(err => {
            console.log(err)
        });
    }
}

const mapStateToProps = (state) => ({
    projectList: state.getProjectList
});

export default withRouter(connect(mapStateToProps, { getProjectList })(Projectgrid));