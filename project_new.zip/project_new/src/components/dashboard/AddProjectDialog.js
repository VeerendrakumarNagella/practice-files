import React from 'react';
import { Dialog, DialogActionsBar } from '@progress/kendo-react-dialogs';
import '@progress/kendo-theme-default/dist/all.css';
import { faPlusSquare, faSave } from '@fortawesome/free-solid-svg-icons';
import Button from './../common/controls/button';
import { createNewProjectReducer } from '../../redux/Actions/createNewProject';
import {createNewCustomer,getUserCustomers,getCustomersListReducer} from '../../redux/Actions/createNewCustomer';
import { connect } from 'react-redux';
import { guid } from '../common/Utilities';
import { getProjectList } from './../../redux/Actions/getProjectList';
import './addproject.scss';
import axios from 'axios';




class AddProjectDialog extends React.Component {

    
    
    constructor(props) {
        super(props);
        this.state = {
            custID: '',
            customerDetails: {},
            data:[],
            CustomerID:[],
            visible: false,
            fields: {
                projectname: "Project " + this.getRandomProjectName(),
                customername: "",
                contactname: "",
                emailid: "",
                mobileno: "",
                disablecustomerfields:true
            },
            details:[],
            errors: {},
            ProjectID: guid()
        };
        this.toggleprojectDialog = this.toggleprojectDialog.bind(this);
        this.getRandomProjectName = this.getRandomProjectName.bind(this);
        this.validateForm = this.validateForm.bind(this);
        this.submitCustomerListForm = this.submitCustomerListForm.bind(this);
        //this.getUserCustomersReducer=props.getUserCustomersReducer(this);
    }

    toggleprojectDialog() {
        this.props.getUserCustomers();
        this.setState({
            visible: !this.state.visible,
            fields: {
                projectname: "Project " + this.getRandomProjectName(),
                customername: "",
                contactname: "",
                emailid: "",
                mobileno: ""
            },
            errors: {},
            ProjectID: guid(),
            
        });

       
    }
    // UNSAFE_componentWillReceiveProps(nextProps) {
    //     console.log("next props", nextProps)
    //     this.setState({
    //         data: nextProps.userCustomers
    //     })
    // }

    componentDidUpdate(prevProps,prevState) {
        if (this.props.userCustomers !== prevProps.userCustomers) {
            console.log("Data is",this.props.userCustomers);
            this.setState({
                data: this.props.userCustomers,
                details: this.state.customerDetails.AddressList,
                emailid: this.cName
            })
        }
    }
    

    componentDidMount(){
        // console.log("Data using Reducer:", this.props.UserCustomersReducer)
        // var headers = {
        //     'Content-Type': 'application/json',
        //     'XUsername': 'sudheerkumar.tangudu@utc.com',
        // }

        // axios({
        //     url: `https://ngecatapplicationservice.azurewebsites.net/api/Customer/GetUserCustomers`,
        //     method: "GET",
        //     headers: headers
        // }).then(res => {
           
        //     this.setState({data:res.data})
        //   console.log("Data is",this.state.data)
        // }).catch(err => {
        //     console.log(err)
        // });
        
   }
    getRandomProjectName() {
        var projectName = '';
        var randomNumber = 0;
        randomNumber = Math.floor(Math.random() * (10000));
        projectName = projectName + ' ' + randomNumber;
        return projectName;
    }

    submitCustomerListForm(e) {
        e.nativeEvent.preventDefault();
        if (this.validateForm(e.nativeEvent)) {
            this.props.createNewProjectReducer(this.state.ProjectID, this.state.fields.projectname);
            this.toggleprojectDialog();
            this.props.getProjectList("sudheerkumar.tangudu@utc.com");
        }
    }

    handleChange = (event) => {

        this.setState( prevState => ({
            //custID: event.target.value,
            fields: {                   // object that we want to update
                ...prevState.fields,    // keep all other key-value pairs
                emailid: this.cName       // update the value of specific key
            }})
        )
        
    }

    GetCustomerDetailsByName = () => {
        if (this.state.custID) {
            var customerID = this.state.custID;        
            axios({
                url: "https://ngecatapplicationservice.azurewebsites.net/api/Customer/GetCustomerAddressList?CustomerID="+`${customerID}`,
                method: "GET",
                headers:{
                    'Content-Type': 'application/json',
                    'Accept':'application/json',
                    'XUsername': 'sudheerkumar.tangudu@utc.com'
                },
            }).then(res => {            
                this.setState({
                    customerDetails: res.data
                })
            }).catch(err => {
                console.log(err)
            });   
        }    
    }

    

    validateForm(e) {
        e.preventDefault();
        let fields = this.state.fields;
        fields[e.target.name] = e.target.value;
        let errors = this.state.errors;
        let formIsValid = true;
        switch(e.target.name)
        {
            case "projectname": if (!fields["projectname"]) {
                                    formIsValid = false;
                                    errors["projectname"] = "*Please enter your projectname.";
                                }
                                if (typeof fields["projectname"] !== "undefined") {
                                    if (!fields["projectname"].match(/^[A-Za-z0-9 _]*[A-Za-z0-9][A-Za-z0-9 _]*$/)) {
                                        formIsValid = false;
                                        errors["projectname"] = "*Please enter alphabet characters only.";
                                    }
                                }
                                formIsValid && (errors["projectname"] = ""); 
                                break;
            case "customername":  if (!fields["customername"]) {
                                    formIsValid = false;
                                    errors["customername"] = "*Please enter your customername.";
                                }
                                if (typeof fields["customername"] !== "undefined") {
                                  
                                  //  console.log( "customers: ",this.props.getUserCustomersReducer);
                                    if (!fields["customername"].match(/^[a-zA-Z ]*$/)) {
                                        formIsValid = false;
                                        errors["customername"] = "*Please enter alphabet characters only.";
                                    }
                                }
                               
                         

                                formIsValid && (errors["customername"] = ""); 
                                break;
             case "contactname":  if (!fields["contactname"]) {
                                        formIsValid = false;
                                        errors["contactname"] = "*Please enter your contactname.";
                                    }
                                    if (typeof fields["contactname"] !== "undefined") {
                                        if (!fields["contactname"].match(/^[a-zA-Z ]*$/)) {
                                            formIsValid = false;
                                            errors["contactname"] = "*Please enter alphabet characters only.";
                                        }
                                    }
                                    formIsValid && (errors["contactname"] = "");
                                    break;

             case "emailid":        if (!fields["emailid"]) {
                                        formIsValid = false;
                                        errors["emailid"] = "*Please enter your email-ID.";
                                    }
                                    if (typeof fields["emailid"] !== "undefined") {
                                        //regular expression for email validation
                                        var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
                                        if (!pattern.test(fields["emailid"])) {
                                            formIsValid = false;
                                            errors["emailid"] = "*Please enter valid email-ID.";
                                        }
                                    }
                                    formIsValid && (errors["emailid"] = "");
                                    break;
              case "mobileno":  
                                    if (!fields["mobileno"]) {
                                        formIsValid = false;
                                        errors["mobileno"] = "*Please enter your mobile no.";
                                    }
                            
                                    if (typeof fields["mobileno"] !== "undefined") {
                                        if (!fields["mobileno"].match(/^[0-9]{10}$/)) {
                                            formIsValid = false;
                                            errors["mobileno"] = "*Please enter valid mobile no.";
                                        }
                                    }
                                    formIsValid && (errors["mobileno"] = "");
                                    break;
        }

        this.setState({
            errors: errors,
            fields
        });

        return formIsValid;
    }


    render() {
        var cName;
        if (this.state.customerDetails.AddressList) {
            cName = this.state.customerDetails.AddressList.map( (name) => {
                return name.Email
            })
            console.log("Details are",this.state.details);

            
        }
        

        console.log("customer address is:", cName)
        console.log("email is:", this.state.fields.emailid)
        console.log("fields are:", this.state.fields);
        console.log("The state of Cust id is:", this.state.custID)
        const custName = this.state.data.map((customer) => {
            return(
                <option key={customer.CustomerID} value={customer.CustomerID}>
                    {customer.CustomerName} -- {customer.CustomerID}
                </option>
            );
            
        })
        
        
        return (
            <>
                <Button
                    name="Add Project"
                    icon={faPlusSquare}
                    styles="eButton"
                    onClick={this.toggleprojectDialog}

                />
                {this.state.visible && <Dialog title={"New Project"} onClose={this.toggleprojectDialog} width={500}  >
                    <div className="card-block">
                        <form name="CustomerListForm" className="k-form-inline" >
                            <label className="k-form-field">
                                <div className="dialog-dimensions"> <span>Project Name</span></div>
                                <div className="message">
                                    <input className="k-textbox form-control" placeholder="Project Name" name="projectname" value={this.state.fields.projectname} onChange={this.validateForm} />
                                    {/* // onChange={this.validateTextfields.bind(this)} /> */}
                                    <span className="errorMsg">{this.state.errors.projectname}</span>
                                </div>
                            </label>
                            <label className="k-form-field ">
                                <div className="dialog-dimensions"><span>Customer Name</span></div>
                                <div className="message">
                                    <input className="k-textbox  form-control" placeholder="Enter Name" name="customername" value={this.state.fields.customername} 
                                    onChange={this.validateForm} onClick={this.GetCustomerDetailsByName}/>
                                    <span className="errorMsg">{this.state.errors.customername} </span>
                                
                                    <select 
                                        value = {this.state.custID}
                                        onChange = {this.handleChange}
                                        name = "custID"
                                    >
                                         {custName}
                                    </select>
                                </div>
                            </label>
                            <label className="k-form-field" >
                                <div className="dialog-dimensions"><span>Contact Name</span></div>
                                <div className="message disable">
                                    <input className="k-textbox  form-control" placeholder="Enter Name" name="contactname" value={this.state.fields.contactname} onChange={this.validateForm}  />
                                    <span className="errorMsg">{this.state.errors.contactname} </span>
                                </div>


                            </label>
                            <label className="k-form-field">
                                <div className="dialog-dimensions"> <span>Contact Email</span></div>
                                <div className="message disable">  <input className="k-textbox  form-control" placeholder="Enter Email" name="emailid" value={cName} onChange={this.validateForm}  />
                                    <span className="errorMsg">{this.state.errors.emailid}</span>
                                </div>
                            </label>

                            <label className="k-form-field">
                                <div className="dialog-dimensions"><span>Contact Number</span></div>
                                <div className="message disable">  <input className="k-textbox  form-control " placeholder="Enter Contact Number" name="mobileno" value={this.state.fields.mobileno} onChange={this.validateForm}  />
                                    <span className="errorMsg">{this.state.errors.mobileno}</span>
                                </div>
                            </label>

                            <div className="dialog-but">
                                <Button
                                    name="Save"
                                    icon={faSave}
                                    styles="eButtonPrimary"

                                   
                                    style={{ backgroundColor: "#152c73", color: "white" }}
                                    onClick={this.submitCustomerListForm}
                                />
                                <Button
                                    name="Save and add Selection"
                                    icon={faSave}
                                    styles="eButtonPrimary"
                                    style={{ backgroundColor: "#152c73", color: "white" }}
                                    onClick={this.toggleDialog}
                                />
                            </div>
                        </form>
                    </div >



                </Dialog>}
            </>
        );
    }
}


const mapStateToProps = (state) => {
    const userCustomers = state.getUserCustomers.records;
    console.log("Data from mapstatetoprosp:", userCustomers)
    return {
        createNewProjectReducer: state.createNewProjectReducer,
        userCustomers,
        createCustomerReducer:state.createCustomerReducer,
    
    }
};
const mapPropsToDispatch = (dispatch) => props => ({
    UserCustomersReducer: dispatch => (props.getUserCustomersReducer()),
});
export default connect(mapStateToProps, { createNewProjectReducer, getProjectList, getUserCustomers })(AddProjectDialog);
