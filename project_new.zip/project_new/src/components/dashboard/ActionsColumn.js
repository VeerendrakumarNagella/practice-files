import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {faBook, faTrashAlt, faExternalLinkSquareAlt} from '@fortawesome/free-solid-svg-icons';

const ActionsCell = (props) => {
    const projectId = props.dataItem.ProjectID;
    return (
        <td>
            <div className="ActionLinkContainer">
                <span className="ActionLink" title="Project Detail" onClick={e => props.onClickProjectDetail(projectId)} >
                    <FontAwesomeIcon className="columncolor" icon={faBook} />
                </span>
                <span className="ActionLink" data-action="ProjectDownload" title="Project Export" onClick={e => props.onClickProjectDownload(props.dataItem)} >
                    <FontAwesomeIcon className="columncolor" icon={faExternalLinkSquareAlt}  />
                </span>
                <span className="ActionLink" data-action="ProjectDelete" title="Delete Project" onClick={e => props.onClickDeleteItem()}>
                    <FontAwesomeIcon className="columncolor" icon={faTrashAlt} />
                </span>
            </div>
        </td>
    );
}

export default ActionsCell;
