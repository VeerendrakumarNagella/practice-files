import React from 'react';
import './Dashboard.scss';
import { withRouter } from 'react-router';
import { FormattedMessage } from 'react-intl';
import Button from './../common/controls/button';
import CustomDropdown from './../common/controls/customDropdown';
import { faPlusSquare, faFileImport, faFileAlt } from '@fortawesome/free-solid-svg-icons';
import { connect } from 'react-redux';
import { getAllProducts } from './../../redux/Actions/getAllProducts'
import { Dialog } from '@progress/kendo-react-dialogs';
import '@progress/kendo-theme-default/dist/all.css';
import { Upload } from '@progress/kendo-react-upload';
import Projectgrid from './projectgrid';
import AddProjectDialog from './AddProjectDialog';
import { getProjectList } from '../../redux/Actions/getProjectList';

const optionList = [
    {
        name: "Packaged Chillers EMEA"
    }
]


class Dashboard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            visible: false
        };
        this.toggleDialog = this.toggleDialog.bind(this);
        this.onClickDropdown = this.onClickDropdown.bind(this);
        this.DropdownMenuList = this.DropdownMenuList.bind(this);
        this.onClickOptionItem = this.onClickOptionItem.bind(this);
        this.importProject = this.importProject.bind(this);
    }
    toggleDialog() {
        this.setState({
            visible: !this.state.visible
        });
    }
    onClickOptionItem() {
        this.props.history.push(`/Template`);        
    }
    onClickDropdown() {
        if(!this.props.getAllProductsProps.AllProductBuilders.length){
            this.props.getAllProducts();
        }
    } 
    importProject() {
        this.setState({ visible: false });
        this.props.getProjectList();
    }  

    render() {
        return (
            <>
                <nav className="horizontal-menu">
                <div><AddProjectDialog/></div>
                    
                    <Button
                        name="Import Project"
                        onClick={this.toggleDialog}
                        styles = "eButton"
                        icon={faFileImport}
                    />
                    {this.state.visible && <Dialog title={"Import Project"} onClose={this.toggleDialog}>
                        <form className=".k-form-inline">
                            <div className="card dialog-size">
                                <div className="card-block">
                                    <form className="k-form-inline">
                                        <label className="k-form-field">
                                            <span>Project Name</span>
                                            <input className="k-textbox" placeholder="Project Name" />
                                        </label>
                                        <label className="k-form-field">
                                            <span></span>
                                            <Upload
                                                batch={false}
                                                multiple={true}
                                                defaultFiles={[]}
                                                withCredentials={false}
                                                saveUrl={''}
                                                removeUrl={''}
                                            />
                                        </label>
                                    </form>
                                </div>
                            </div>

                            <div className="dialog-but">
                                <button type="button" className="k-button k-primary" onClick={this.importProject}>Save</button>
                            </div>
                        </form>
                    </Dialog>}
                    
                    <CustomDropdown
                        name="Add Selection"
                        DropdownMenuList={(callback) => this.DropdownMenuList(callback)}
                        onClickDropdown={this.onClickDropdown}
                        icon={faFileAlt}
                        handleOnClick={this.onClickOptionItem}
                    />
                </nav>
                {/* <h1><FormattedMessage id="dashboard" defaultMessage="Dashboard" /></h1> */}
                <Projectgrid
                />
            </>
        )
    }

    DropdownMenuList(callback) {
        var obj;
        var DisplayNames = [];
        if(this.props.getAllProductsProps.isLoading) {
            return "Loading..."
        }

        let jsonData = this.props.getAllProductsProps.AllProductBuilders;
        let Data = this.props.getAllProductsProps.AllProductBuilders;

        if (jsonData != null) {
            jsonData.sort(function (a, b) {
                return (a.Name > b.Name) ? 1 : -1;
            });
        }

        if (jsonData !== undefined && jsonData !== null) {
            for (var i = 0; i < jsonData.length; i++) {
                if (jsonData[i].UIVisible.toUpperCase() === 'TRUE') {
                    if (DisplayNames.indexOf(jsonData[i].DisplayName) > -1) {
                        if (jsonData[i].IsDirectFlow === undefined || jsonData[i].IsDirectFlow === null || jsonData[i].IsDirectFlow.toUpperCase() === "FALSE") {
                            obj = <li onClick={e => callback()} key={jsonData[i].Id}>{jsonData[i].DisplayName}</li>
                            return obj
                            //  $("ul.SelectionProductBuilder").append("<li><a href=\"#\" class=\"NewSelectionDD_menu heading-color\" data-productBuilderId=" + jsonData[i].Id + ">" + jsonData[i].DisplayName + "</a></li>");
                        }
                        DisplayNames.push(jsonData[i].DisplayName);
                    }
                    
                    if (Data != null) {
                        Data.sort(function (a, b) {
                            return (a.Name > b.Name) ? 1 : -1;
                        });
    
                        for (var k = 0; k < Data.length; k++) {
                            if (Data[k].UIVisible.toUpperCase() === 'TRUE') {
                                if (jsonData[i].IsDirectFlow !== undefined && jsonData[i].IsDirectFlow !== null && jsonData[i].IsDirectFlow.toUpperCase() === "TRUE") {
                                    obj = <li onClick={e => callback()} key={Data[k].Id}>{jsonData[i].DisplayName}</li>
                                    return obj
                                    //$("ul.SelectionProductBuilder").append("<li><a href=\"#\" data-action=\"AddNewSelection\" class=\"ActionLink NewSelectionDD_menup\" data-productBuilderId=" + Data[k].Builder + " data-selectedModel=" + Data[k].Id + ">" + jsonData[i].DisplayName + "</a></li>");
                                }
                                else {
                                    obj = <li onClick={e => callback()} key={Data[k].Id}>{Data[k].Name}</li>
                                    return obj
                                   // $("ul.SelectionProductBuilder").append("<li><a href=\"#\" data-action=\"AddNewSelection\" class=\"ActionLink NewSelectionDD_submenupadding\" data-productBuilderId=" + Data[k].Builder + " data-selectedModel=" + Data[k].Id + ">" + Data[k].Name + "</a></li>");
                                }
                            }
                        }
                    }
                }
            }
        }
        return obj;
    }

}

const mapStateToProps = (state) => ({
    getAllProductsProps: state.getAllProductsReducer
});

export default withRouter(connect(mapStateToProps, { getAllProducts, getProjectList })(Dashboard));