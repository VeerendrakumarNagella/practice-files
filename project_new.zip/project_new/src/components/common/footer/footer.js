import React from 'react';
import './footer.scss';

const Footer = () => {
    return(
        <footer>
            <div className="container">
                <div className="footer-wrapper">
                    <div className="links">
                        <a href="http://www.carrier.com/carrier/en/us/privacy-notice/" rel="noopener noreferrer" target="_blank">Privacy Notice</a>
                        <a href="https://www.carrier.com/carrier/en/us/terms-of-use/" rel="noopener noreferrer" target="_blank">Terms of Use</a>
                        <a href="https://www.carrier.com/carrier/en/us/about-us/" rel="noopener noreferrer" target="_blank">Contact Us</a>
                    </div>
                    <div>
                        <span></span>
                        <a href="http://www.bis.utc.com/" rel="noopener noreferrer" target="_blank">UTC Climate, Controls &amp; Security,</a>
                        <span>a unit of</span>
                        <a href="http://www.utc.com/" rel="noopener noreferrer" target="_blank">United Technologies Corp.</a> | &nbsp;
                        <a href="https://www.carrier.com" rel="noopener noreferrer" target="_blank">&copy; Carrier Corporation 2019</a>
                    </div>  
                </div>              
            </div>
        </footer>
    );
}

export default Footer;