import React, { useEffect, useState, useRef } from "react";

const LangDropdown = ({ selectedItem, options, onChange }) => {
  const node = useRef();

  const [open, setOpen] = useState(false);

  const handleClick = e => {
    if (node.current.contains(e.target)) {
      return;
    }
    setOpen(false);
  };

  const handleChange = selectedObj => {
    onChange(selectedObj);
    setOpen(false);
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClick);

    return () => {
      document.removeEventListener("mousedown", handleClick);
    };
  }, []);

  return (
    <div ref={node} className="dropdown">
      <span role="button" className="dropdown-toggler text-uppercase" onClick={e => setOpen(!open)}>
        <img src={selectedItem.img} alt={selectedItem.name} /> {selectedItem.name} <span className="caret" />
      </span>
      {open && (
        <ul className="dropdown-menu">
          {options.map((opt, idx) => (
            <li className={opt.name === selectedItem.name ? 'text-uppercase active' : 'text-uppercase'}  key={idx} onClick={e => handleChange(opt)}>
              <img src={opt.img} alt="" /> {opt.name}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default LangDropdown;
