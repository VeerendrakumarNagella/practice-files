import React from 'react';
import './header.scss';
import Logo from './../../../assets/images/Logo.svg';
import LangDropdown from './langDropdown';
import SettingDropdown from './settingDropdown';
import ProfileDropdown from './profileDropdown';
import {connect} from 'react-redux';
import { Link } from 'react-router-dom';
import {getLocale, setLocale} from './../../../redux/Actions/setLocale';
import { LangOpt } from './../../../utilities/languagesutils';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome } from '@fortawesome/free-solid-svg-icons';

class Header extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
           lang: this.createLangStr(),
           unit: "Metric"
        }
        this.handleChangeLang = this.handleChangeLang.bind(this);
        this.handleChangeUnit = this.handleChangeUnit.bind(this);
    }

    static getDerivedStateFromProps(props, state){
        let lang;
        LangOpt.forEach(opt => { 
            if(opt.name.toUpperCase() === props.lang.name.toUpperCase()){
                lang = opt;
                return;
            }
        });

        return { ...state, lang };
    }

    componentDidMount() {
        this.props.getLocale();
    }

    createLangStr() {
        var obj;
        LangOpt.forEach(opt => { 
            if(opt.name === 'English'){
                obj = opt;
                return;
            }
        })
        return obj;
    }
    handleChangeLang(opt) {
        let unit = (this.state.unit === "Imperial") ? "English" : "Metric";
        this.props.setLocale(opt, unit);
        this.setState({lang: opt});
    }
    handleChangeUnit(value) {
        this.setState({unit: value});
    }

    render() {
        return(
            <header>
                <div className="container">
                    <div className="header-wrapper">
                        <div className="brand-logo">
                            <Link to='/'><img src={Logo} alt="E CAT" /></Link>
                            <Link to='/' className="btn-home"><FontAwesomeIcon icon={faHome} /></Link>
                        </div>
                        <nav className="dropdown-right">
                            <LangDropdown
                                selectedItem={this.state.lang}
                                options={LangOpt}
                                onChange={this.handleChangeLang}
                            />
                            <SettingDropdown
                                selectedItem={this.state.unit}
                                onchange={this.handleChangeUnit}
                            />
                            <ProfileDropdown 
                                fullName="Venkatesh Patnam"
                            />
                        </nav>
                    </div>                                
                </div>
            </header>
        );
    }    
}

const mapStateToProps = (state) => ({
    lang: state.locale
});

export default connect(mapStateToProps, {getLocale, setLocale})(Header);