import React, { useEffect, useState, useRef } from "react";
import UserIcon from './../../../assets/images/user-icon.png';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faUserEdit, faLock, faInfoCircle } from '@fortawesome/free-solid-svg-icons';

const ProfileDropdown = ({ fullName }) => {
  const node = useRef();

  const [open, setOpen] = useState(false);

  const handleClick = e => {
    if (node.current.contains(e.target)) {
      return;
    }
    setOpen(false);
  };

  const handleChange = selectedValue => {
    setOpen(false);
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClick);

    return () => {
      document.removeEventListener("mousedown", handleClick);
    };
  }, []);

  return (
    <div ref={node} className="dropdown">
      <span role="button" className="dropdown-toggler" onClick={e => setOpen(!open)}>
        <img src={UserIcon} alt="" /> {fullName} <span className="caret" />
      </span>
      {open && (
        <ul className="dropdown-menu">
          <li onClick={e => handleChange()}><FontAwesomeIcon icon={faUserEdit} /> Edit Profile</li>
          <li onClick={e => handleChange()}><FontAwesomeIcon icon={faLock} /> Change User Role</li>
          <li onClick={e => handleChange()}><FontAwesomeIcon icon={faInfoCircle} /> About E-CAT</li>
          <div className="text-center"><label className="label-center">Sales Office</label></div>
        </ul>
      )}
    </div>
  );
};

export default ProfileDropdown;
