import React, { useEffect, useState, useRef } from "react";
import SettingIcon from './../../../assets/images/setting-icon.png';

const SettingDropdown = ({ selectedItem, onchange }) => {
  const node = useRef();

  const [open, setOpen] = useState(false);

  const handleClick = e => {
    if (node.current.contains(e.target)) {
      return;
    }
    setOpen(false);
  };

  const handleChange = (val) => {
    onchange(val)
    setOpen(false);
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClick);

    return () => {
      document.removeEventListener("mousedown", handleClick);
    };
  }, []);

  return (
    <div ref={node} className="dropdown">
      <span role="button" className="dropdown-toggler" onClick={e => setOpen(!open)}>
        <img src={SettingIcon} alt="" />
      </span>
      {open && (
        <ul className="dropdown-menu">
          <li className={selectedItem === "Metric" ? 'active' : ''} onClick={e => handleChange("Metric")}>Metric</li>
          <li className={selectedItem === "Imperial" ? 'active' : ''} onClick={e => handleChange("Imperial")}>Imperial</li>
        </ul>
      )}
    </div>
  );
};

export default SettingDropdown;
