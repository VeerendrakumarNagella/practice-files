import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const Button = (props) => {
    return (
        <button className={props.styles} onClick={e => props.onClick(e)}>
            {props.icon && <FontAwesomeIcon icon={props.icon} />}
            {props.name}
        </button>

        
    )
}

export default Button;