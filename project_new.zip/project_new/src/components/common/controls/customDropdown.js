import React, { useEffect, useState, useRef } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const CustomDropdown = (props) => {
    const node = useRef();
    const [open, setOpen] = useState(false);

    const handleClick = e => {
        if (node.current.contains(e.target)) {
        return;
        }
        setOpen(false);
    };
    // const DropdownMenuList = () => {

    // }
    const handleBtnClick = () => {
        props.onClickDropdown()
        setOpen(!open)
    }

    const handleChange = () => {
        props.handleOnClick()
        setOpen(false);
    };

    useEffect(() => {
        document.addEventListener("mousedown", handleClick);

        return () => {
        document.removeEventListener("mousedown", handleClick);
        };
    }, []);

    return (
        <div ref={node} className="dropdownButton">
            <button className="eButton" onClick={e => handleBtnClick()}>
                {props.icon && <FontAwesomeIcon icon={props.icon} />}
                {props.name} <span className="caret" />
            </button>
            {open && (
                <ul className="dropdown-menu">
                    {props.DropdownMenuList(e => handleChange())}
                </ul>
            )}
        </div>
    )
}

export default CustomDropdown;