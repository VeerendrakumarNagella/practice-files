import {
    LOCALE_SET_START, 
    LOCALE_SET_FULFILLED, 
    LOCALE_SET_FAILED } from './../constants/constant';
import { API } from '../constants/apiContants';
import axios from 'axios';
import { LangOpt } from './../../utilities/languagesutils'; 
const userAlearyExit = "User already created his preferences. Try Update preferences";

export const getLocale = (lang) => (dispatch) => {
    // sessionStorage.ecatLang = lang;
    // dispatch({
    //     type: LOCALE_SET_FULFILLED,
    //     data: { lang: lang.lang, Language: lang.language  }
    // })
    
    var headers = {
        'Content-Type': 'application/json',
        'XUsername': 'patnamv',
    }
    axios({
        url: API.GET_ECAT_USER,
        method: "GET",
        headers: headers,
    }).then(res => {
        let lang;
        LangOpt.forEach(opt => { 
            if(opt.name.toUpperCase() === res.Language.toUpperCase()){
                lang = opt.lang;
                return;
            }
        });
        
        dispatch({
            type: LOCALE_SET_FULFILLED,
            data: { lang: lang, Language: res.data.Language }
        });
    }).catch(err => {
        dispatch({
            type: LOCALE_SET_FAILED,
            error: err
        });
    })
}

export const setLocale = (opt, unit) => (dispatch) => {
    var jsonData = {
        "UnitSystem": unit,
        "Language": opt.name,
        "SalesEntity": "",
        "IsCacheClear": ""
     }
    var headers = {
        'Content-Type': 'application/json',
        'XUsername': 'patnamv',
    }
    dispatch({ type: LOCALE_SET_START });    
    axios({
        url: API.POST_CREATE_LANGUAGE,
        method: "POST",
        headers: headers,
        data: jsonData,
    }).then(result => { 
        if(result) {
            dispatch({
                type: LOCALE_SET_FULFILLED,
                data: {...result.data, lang: opt.lang}
            });
            sessionStorage.ecatLang = JSON.stringify({ lang: opt.lang, Language: result.data.language });
        }     
    }).catch(request => {  
        if(request && request.response.data.Message[0] === userAlearyExit) {
            isUpdateUserPerrences();
        } else {
            console.log("Error")
        }             
    });

    function isUpdateUserPerrences() {
        axios({
            url: API.POST_UPDATE_LANGUAGE,
            method: "POST",
            headers: headers,
            data: jsonData,
        }).then(result => {  
            sessionStorage.ecatLang = JSON.stringify({ lang: opt.lang, Language: result.data.language });          
            dispatch({
                type: LOCALE_SET_FULFILLED,
                data: {...result.data, lang: opt.lang}
            })
        }).catch((request) => {  
            console.log(request);
        });
    }    
};