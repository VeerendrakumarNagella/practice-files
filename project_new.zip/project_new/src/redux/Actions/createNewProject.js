import { FETCH_ADDPROJECT_START,FETCH_ADDPROJECT_FULFILLED,FETCH_ADDPROJECT_FAILED } from '../constants/constant.js';
import { API } from '../constants/apiContants';
import axios from 'axios';

export const createNewProjectReducer= (projectID, projectName) => (dispatch) => {
    var jsonData = {
        "ProjectID":projectID,
        "ProjectName": projectName, 
     }
     var headers = {
        'Content-Type': 'application/json',
        'XUsername': 'sudheerkumar.tangudu@utc.com',
        
        'Accept':'application/json',
       
        'Access-Control-Allow-Origin':'*'
    }
    dispatch({ type: FETCH_ADDPROJECT_START});

    axios({
        url: API.POST_ADDPROJECT,
        method: "POST",
        headers: headers,
        data: jsonData,
    }).then(result => {       
        dispatch({
            type: FETCH_ADDPROJECT_FULFILLED,
            data: result.data
        })
    }).catch((request) => {  
        console.log(request);
    });
}

