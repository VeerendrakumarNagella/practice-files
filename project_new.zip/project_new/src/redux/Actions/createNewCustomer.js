import { CREATE_CUSTOMER_START,CREATE_CUSTOMER_FULFILLED,CREATE_CUSTOMER_FAILED} from '../constants/constant.js';
import {FETCH_USER_CUSTOMERS_START,FETCH_USER_CUSTOMERS_FULFILLED,FETCH_USER_CUSTOMERS_FAILED} from '../constants/constant.js';
import {GET_CUSTOMER_LIST_START,GET_CUSTOMER_LIST_FULFILLED,GET_CUSTOMER_LIST_FAILED} from '../constants/constant.js';
import { API } from '../constants/apiContants';
import axios from 'axios';

export const createNewCustomerReducer= (customerID, customerInformation,customerName,companyName) => (dispatch) => {
    
    var jsonData = {
        "CustomerID": "",
        "CustomerInformation": "",
        "CustomerName": "Ashwini",
        "CompanyName": "HRDC"
    }
     var headers = {
        'Content-Type': 'application/json', 
       'XUsername': 'sudheerkumar.tangudu@utc.com',
        'Accept':'application/json',
        'Access-Control-Allow-Origin':'*'
    }
    dispatch({ type: CREATE_CUSTOMER_START});

    axios({
        url: API.POST_CREATE_CUSTOMER,
        method: "POST",
        headers: headers,
        data: jsonData,
    }).then(result => {       
        dispatch({
            type: CREATE_CUSTOMER_FULFILLED,
            data: result.data
        })
    }).catch((request) => {  
        console.log(request);
    });
}

export const getUserCustomers = () => (dispatch) => {
    dispatch({ type: FETCH_USER_CUSTOMERS_START});
    axios(API.GET_USER_CUSTOMERS, { 
        method: 'GET',
        headers:{
            'Content-Type': 'application/json', 
            'XUsername': 'sudheerkumar.tangudu@utc.com',
            'Accept':'application/json',
            'Access-Control-Allow-Origin':'*'
        }       
       })
       .then(res => {
        dispatch({
            type: FETCH_USER_CUSTOMERS_FULFILLED,
            data: res.data
        });
    })
    .catch(error => {
        dispatch({
            type: FETCH_USER_CUSTOMERS_FAILED,
            data: error
        })
    });
};

export const getCustomersListReducer = (userID) => (dispatch) => {
    
    dispatch({ type: GET_CUSTOMER_LIST_START})
    axios(API.GET_CUSTOMER_LIST+`${userID}`, { 
        method: 'GET',
        headers:{
            'Content-Type': 'application/json',
            'Accept':'application/json',
            'XUsername': 'sudheerkumar.tangudu@utc.com',
            'Access-Control-Allow-Origin':'*'
        }       
       }).then(res => {
        dispatch({
            type: GET_CUSTOMER_LIST_FULFILLED,
            data: res.data
        });
    }).catch(error => {
        dispatch({
            type: GET_CUSTOMER_LIST_FAILED,
            data: error
        })
    });
};

