import {
    GET_ALL_PRODUCTS_START, 
    GET_ALL_PRODUCTS_FULFILLED, 
    GET_ALL_PRODUCTS_FAILED } from '../constants/constant';
import { API } from '../constants/apiContants';
import axios from 'axios';

export const getAllProducts = () => (dispatch) => {
    var headers = {
        'Content-Type': 'application/json',
        'XUsername': 'sudheerkumar.tangudu@utc.com',
    }
    dispatch({ type: GET_ALL_PRODUCTS_START }); 
    axios({
        url: API.GET_ALL_PRODUCTS_BUILDER,
        method: "GET",
        headers: headers,
    }).then(res => {
        dispatch({
            type: GET_ALL_PRODUCTS_FULFILLED,
            data: res.data
        });
    }).catch(err => {
        dispatch({
            type: GET_ALL_PRODUCTS_FAILED,
            error: err
        });
    });
}