import { FETCH_PROJECTLIST_START,FETCH_PROJECTLIST_FULFILLED,FETCH_PROJECTLIST_FAILED } from '../constants/constant';
import { API } from './../constants/apiContants';
import axios from 'axios';

export const getProjectList = (userID) => (dispatch) => {
    
    dispatch({ type: FETCH_PROJECTLIST_START})
    axios(API.GET_PROJECTLIST+`${userID}`, { 
        method: 'GET',
        headers:{
            'Content-Type': 'application/json',
            'Accept':'application/json',
            'XUsername': 'sudheerkumar.tangudu@utc.com',
            'Access-Control-Allow-Origin':'*'
        }       
       }).then(res => {
        dispatch({
            type: FETCH_PROJECTLIST_FULFILLED,
            data: res.data
        });
    }).catch(error => {
        dispatch({
            type: FETCH_PROJECTLIST_FAILED,
            data: error
        })
    });
};
