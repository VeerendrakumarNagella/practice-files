import { combineReducers } from 'redux';
import localeReducer from './localeReducer';
import getAllProductsReducer from './getAllProductsReducer';
import getprojectListReducer from './getProjectListReducer';
import createNewProjectReducer from './createNewProjectReducer';
import createNewCustomerReducer from './createCustomerReducer';
import getCustomersListReducer from './createCustomerReducer';
import getUserCustomersReducer from './getUserCustomersReducer';
// import userReducer from './userReducer';

const rootReducer = combineReducers({
    locale: localeReducer,
    getProjectList: getprojectListReducer,
    createNewProject:createNewProjectReducer,
    getAllProductsReducer: getAllProductsReducer,
    createNewCustomerReducer:createNewCustomerReducer,
    getUserCustomers: getUserCustomersReducer,
    getCustomersListReducer:getCustomersListReducer,
});

export default rootReducer;