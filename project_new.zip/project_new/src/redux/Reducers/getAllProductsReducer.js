import {
    GET_ALL_PRODUCTS_START, 
    GET_ALL_PRODUCTS_FULFILLED, 
    GET_ALL_PRODUCTS_FAILED } from './../constants/constant';

const initialState = {
    isLoading: false,
    AllProductBuilders: [],
    AllProductBuilderModels: []
};

export default function reducer(state = initialState, action){
    switch(action.type){
        case GET_ALL_PRODUCTS_START:
            return {
                ...state,
                isLoading: true
            }
        case GET_ALL_PRODUCTS_FULFILLED:
            return {
                ...state,
                isLoading: false,
                AllProductBuilders: action.data.AllProductBuilders,
                AllProductBuilderModels: action.data.AllProductBuilderModels
            }
        case GET_ALL_PRODUCTS_FAILED:
            return {
                ...state,
                isLoading: false,
                error: action.error
            }
        default:
        return state;
    }
};