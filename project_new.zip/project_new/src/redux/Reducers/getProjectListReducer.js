
import { FETCH_PROJECTLIST_START,FETCH_PROJECTLIST_FULFILLED,FETCH_PROJECTLIST_FAILED } from '../constants/constant';

const initialState = {
    records: [],
    isLoading: false,
    error: ''
};

export default function (state = initialState, action){
    switch(action.type){
        case FETCH_PROJECTLIST_START:
            return {
                ...state,
                isLoading: true
            }
        case FETCH_PROJECTLIST_FULFILLED:
            return {
                ...state,
                isLoading: false,
                records: action.data,                
            }
        case FETCH_PROJECTLIST_FAILED:
            return {
                ...state,
                isLoading: false,
                error: action.data
            }
        default:
        return state;
    }
};