import { FETCH_ADDPROJECT_START, FETCH_ADDPROJECT_FULFILLED, FETCH_ADDPROJECT_FAILED } from '../constants/constant';

const initialState = {
    records: [],
    isLoading: false,
    error: ''
};

export default function createNewProjectReducer(state = initialState, action){
    switch(action.type){
        case FETCH_ADDPROJECT_START:
            return {
                ...state,
                isLoading: true
            }
        case FETCH_ADDPROJECT_FULFILLED:
            return {
                ...state,
                isLoading: false,
                records: action.data
            }
        case FETCH_ADDPROJECT_FAILED:
            return {
                ...state,
                isLoading: false,
                error: action.data
            }
        default:
        return state;
    }
};