import {CREATE_CUSTOMER_START, CREATE_CUSTOMER_FULFILLED, CREATE_CUSTOMER_FAILED } from '../constants/constant';
import {GET_CUSTOMER_LIST_START,GET_CUSTOMER_LIST_FULFILLED,GET_CUSTOMER_LIST_FAILED} from '../constants/constant.js';

const initialState = {
    records: [],
    isLoading: false,
    error: ''
};
const customerinitialState = {
    customerrecords: [],
    customerisLoading: false,
    customererror: ''
};
const CustomerListinitialState={
    records: [],
    isLoading: false,
    error: ''
}

export default function createCustomerReducer(state = initialState, action){
    switch(action.type){
        case CREATE_CUSTOMER_START:
            return {
                ...state,
                isLoading: true
            }
        case CREATE_CUSTOMER_FULFILLED:
            return {
                ...state,
                isLoading: false,
                records: action.data
            }
        case CREATE_CUSTOMER_FAILED:
            return {
                ...state,
                isLoading: false,
                error: action.data
            }
        default:
        return state;
    }
};

export function getCustomersListReducer(state = CustomerListinitialState, action){
    switch(action.type){
        case   GET_CUSTOMER_LIST_START:
            console.log("Get cust details");
            return {
                ...state,
                isLoading: true
            }
        case GET_CUSTOMER_LIST_FULFILLED:
            return {
                ...state,
                isLoading: false,
                records: action.data
            }
        case GET_CUSTOMER_LIST_FAILED:
            return {
                ...state,
                isLoading: false,
                error: action.data
            }
        default:
        return state;
    }
};