import {FETCH_USER_CUSTOMERS_START,FETCH_USER_CUSTOMERS_FULFILLED,FETCH_USER_CUSTOMERS_FAILED} from '../constants/constant';

const customerinitialState = {
    customerrecords: [],
    customerisLoading: false,
    customererror: ''
};

export default function getUserCustomersReducer(state = customerinitialState, action){
    switch(action.type){
        case FETCH_USER_CUSTOMERS_START:
            return {
                ...state,
                isLoading: true
            }
        case FETCH_USER_CUSTOMERS_FULFILLED:
            return {
                ...state,
                isLoading: false,
                records: action.data
            }
        case FETCH_USER_CUSTOMERS_FAILED:
            return {
                ...state,
                isLoading: false,
                error: action.data
            }
        default:
            return state;
    }
};
