//'https://ngecatapplicationservice.azurewebsites.net/' || 'http://nextgenecat:8891/'
var baseURL = 'https://ngecatapplicationservice.azurewebsites.net/';
//var cloudurl ='http://nextgenecat:8891/'
export const API = {
    GET_ECAT_USER: `${baseURL}api/User/GetECatUserPreferences`,
    POST_CREATE_LANGUAGE: `${baseURL}api/User/CreateUserPreference`,
    POST_UPDATE_LANGUAGE: `${baseURL}api/User/UpdateUserPreference`,
    GET_PROJECTLIST: `${baseURL}api/Project/GetUserProjectList?userid=`,
    POST_ADDPROJECT: `${baseURL}/api/Project/CreateProject` ,
    GET_ALL_PRODUCTS_BUILDER: `${baseURL}api/MasterData/GetAllProductBuilderModels`,
    POST_CREATE_CUSTOMER:`${baseURL}api/Customer/CreateCustomer`,
    POST_UPDATE_CUSTOMER:`${baseURL}api/Project/UpdateProjectCustomer`,
    POST_UPDATE_PROJECT: `${baseURL}api/Project/UpdateProjectName`,
    GET_USER_CUSTOMERS: `${baseURL}api/Customer/GetUserCustomers`,
    GET_CUSTOMER_LIST: `${baseURL}api/Customer/GetCustomerAddressList`,
    POST_UPDATE_PROJECTNAME:`${baseURL}api/Project/UpdateProjectName`

}